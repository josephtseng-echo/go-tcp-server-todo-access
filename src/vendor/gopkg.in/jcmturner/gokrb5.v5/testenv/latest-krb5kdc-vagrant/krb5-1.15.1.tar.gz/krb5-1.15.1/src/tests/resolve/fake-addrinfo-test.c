/* -*- mode: c; c-basic-offset: 4; indent-tabs-mode: nil -*- */
#define USE_FAKE_ADDRINFO
#include "addrinfo-test.c"
