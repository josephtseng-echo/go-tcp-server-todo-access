#ifndef _TEST_CCAPI_CONSTANTS_H_
#define _TEST_CCAPI_CONSTANTS_H_

int check_constants(void);

#endif /* _TEST_CCAPI_CONSTANTS_H_ */
